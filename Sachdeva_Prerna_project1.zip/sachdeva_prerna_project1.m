%TASK-1 
random_nos=[10,100,1000,10000];%create vector 
pi_value=zeros(size(random_nos));%stores pi estimate for each sample size
errors=zeros(size(random_nos));%store the diference between true and estimated pi
times=zeros(size(random_nos));%store the execution time for each sample size

for i=1:length(random_nos)%loop goes through random_nos
    N = random_nos(i);
    in=0;%counts that points falls inside quarter circle
    tic;%starts a timer
    for j=1:N% inner loop generates n random points
        %generates random points(x,y)
        x=rand();
        y=rand(); 
        %checks if the point lies inside quarter circle of radius 1
        if(x^2+y^2<=1)
            in=in+1;
        end
    end%ends loop
    times(i)=toc;%stops timer

    %estimates pi using monte carlo method
    pi_value(i)=4*in/N;
    errors(i)=abs(pi_value(i)-pi);
end

%creates a new figure 
figure;
plot(random_nos, pi_value, '-o')
xlabel('N')
ylabel('pi-value')
title('N vs pi-value')

figure;
plot(random_nos, errors, '-o')
xlabel('N')
ylabel('error')
title('N vs error')

figure;
plot(random_nos, times, '-o')
xlabel('N')
ylabel('times')
title('N vs times')





%TASK -2
precision = 3;% no of sig figures for rounding       
batch = 1000;% no of random points         
streakNeeded = 20;% how many times the rounded pi estimate must stay before stopping

in = 0; 
total = 0;% counts total no of generated points
rounded_prev = NaN;%stores previously rounded pi estimate 
streak = 0;


while streak < streakNeeded
    %generates batch random x and y coordinates
    x = rand(batch,1); 
    y = rand(batch,1);
    %checks which points fall inside quarter circle
    in = in + sum(x.^2 + y.^2 <= 1);
    total = total + batch;
    %estimates pi
    pii_value = 4*in/total;
    %round pi estimate 
    rounded = str2double(sprintf('%.*g', precision, pii_value));
    %checks current rounded equal to previous one 
    if rounded == rounded_prev
        streak = streak + 1;
    else
        streak = 0;
        rounded_prev = rounded;
    end
end% end loop
disp('TASK-2')
disp(['pi estimate = ' num2str(pii_value)])
disp(['Rounded to ' num2str(precision) ' sig figs = ' num2str(rounded)])
disp(['Total points used = ' num2str(total)])







