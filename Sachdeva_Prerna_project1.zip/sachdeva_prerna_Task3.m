function pii_value = piii_value_func(precision)%defined function to calculate pii_value
   
    disp('TASK-3')
    %how many sig fig 
    precision = 3;
    %no of random points generated per loop
    batch = 200;         
    streakNeeded = 20; 
    in = 0;
    total = 0;
    rounded_prev = NaN;
    streak = 0;

    %figure plotting
    figure; 
    hold on; 
    axis([0 1 0 1]); 
    axis square;
    title('Estimation of \pi');
    xlabel('x'); ylabel('y');
    

    while streak < streakNeeded
        %generate batch random points
        x = rand(batch,1);
        y = rand(batch,1);
        %checks if point lies inside the quarter circle
        inside = (x.^2 + y.^2) <= 1;

        in    = in    + sum(inside);
        total = total + batch;
        %plots inside and outside points
        scatter(x(inside),  y(inside),  10, 'b', 'filled');
        scatter(x(~inside), y(~inside), 10, 'r', 'filled');
        drawnow limitrate
        %monte carlo formula
        pii_value = 4 * in / total;
        rounded   = str2double(sprintf('%.*g', precision, pii_value));
        %checks stability
        if rounded == rounded_prev
            streak = streak + 1;
        else
            streak = 0;
            rounded_prev = rounded;
        end
    end

  
    disp(['pi estimate = ' num2str(pii_value)]);
    disp(['Rounded to ' num2str(precision) ' sig figs = ' num2str(rounded)]);
    disp(['Total points used = ' num2str(total)]);

 
    text(0.5, 0.07, ['\pi \approx ' num2str(rounded)], ...
          'FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');

end
%calling function
piii_value_func(3)